const questions = [
  "I’m fine with a competitive learning environment",
  "I prefer a smaller university",
  "I prefer a university with a large campus",
  "I prefer a university with modern facilities",
  "I want a campus that's easy to walk across",
  "I prefer a university in the city",
  "I want a school with lots of extracurricular activities",
  "I want a school with school spirit",
  "I want a well known university",
  "I prefer a school in a quiet town",
  "I care about good on campus housing",
  "I prefer a university that gives good financial aid",
  "I want a respected university",
  "I want a university with good study spaces",
  "I prefer a social campus"
];

const scale = [
  { label: "Strongly Disagree", value: 1 },
  { label: "Disagree", value: 2 },
  { label: "Slightly Disagree", value: 3 },
  { label: "Neutral", value: 4 },
  { label: "Slightly Agree", value: 5 },
  { label: "Agree", value: 6 },
  { label: "Strongly Agree", value: 7 }
];

const schools = [
  { min: 0, max: 20, schools: ["Algoma University", "Université de Hearst", "Nipissing University", "Laurentian University", "Lakehead University"] },
  { min: 21, max: 40, schools: ["Brock University", "Trent University", "University of Windsor", "Ontario Tech University", "Wilfrid Laurier University"] },
  { min: 41, max: 60, schools: ["University of Ottawa", "Carleton University", "Queen’s University", "Western University", "University of Guelph"] },
  { min: 61, max: 80, schools: ["McMaster University", "York University", "Toronto Metropolitan University", "University of Waterloo", "University of Toronto"] },
  { min: 81, max: 100, schools: ["University of Toronto", "University of Waterloo", "McMaster University", "Queen’s University", "Northern Ontario School of Medicine"] }
];

const form = document.getElementById("compatquiz");

questions.forEach((q, i) => {
  form.insertAdjacentHTML("beforeend", `<p>${q}</p>`);

  scale.forEach(s => {
    form.insertAdjacentHTML(
      "beforeend",
      `
      <label>
        <input type="radio" name="q${i}" value="${s.value}">
        ${s.label}
      </label>
      `
    );
  });
});

document.getElementById("submit").addEventListener("click", function (e) {
  e.preventDefault();

  let score = 0;

  for (let i = 0; i < questions.length; i++) {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);

    if (!selected) {
      alert("Please answer every question.");
      return;
    }

    score += Number(selected.value);
  }

  const maxScore = questions.length * 7;
  const percent = Math.round((score / maxScore) * 100);

  const match = schools.find(s => percent >= s.min && percent <= s.max);

  alert(
    `Your Score: ${percent}%\n\nRecommended Schools:\n${match.schools.join(", ")}`
  );
});

                        