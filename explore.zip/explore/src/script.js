 const schools = [
  { name: "Algoma University", url: "https://www.algomau.ca" },
  { name: "Brock University", url: "https://www.brocku.ca" },
  { name: "Carleton University", url: "https://www.carleton.ca" },
  { name: "Lakehead University", url: "https://www.lakeheadu.ca" },
  { name: "Laurentian University", url: "https://www.laurentian.ca" },
  { name: "McMaster University", url: "https://www.mcmaster.ca" },
  { name: "Nipissing University", url: "https://www.nipissingu.ca" },
  { name: "Northern Ontario School of Medicine (NOSM) University", url: "https://www.nosm.ca" },
  { name: "OCAD University", url: "https://www.ocadu.ca" },
  { name: "Ontario Tech University", url: "https://www.ontariotechu.ca" },
  { name: "Queen’s University", url: "https://www.queensu.ca" },
  { name: "Royal Military College", url: "https://www.rmc.ca" },
  { name: "Toronto Metropolitan University", url: "https://www.torontomu.ca" },
  { name: "Trent University", url: "https://www.trentu.ca" },
  { name: "University of Guelph", url: "https://www.uoguelph.ca" },
  { name: "Université de Hearst", url: "https://www.uhearst.ca" },
  { name: "Université de l’Ontario français", url: "https://www.uontario.ca" },
  { name: "University of Ottawa", url: "https://www.uottawa.ca" },
  { name: "University of Toronto", url: "https://www.utoronto.ca" },
  { name: "University of Waterloo", url: "https://www.uwaterloo.ca" },
  { name: "University of Windsor", url: "https://www.uwindsor.ca" },
  { name: "Western University", url: "https://www.westernu.ca" },
  { name: "Wilfrid Laurier University", url: "https://www.wlu.ca" },
  { name: "York University", url: "https://www.yorku.ca" }
];

   

const input = document.getElementById("searchInput");
const results = document.getElementById("results");

input.addEventListener("input", () => {
  const query = input.value.toLowerCase();
  results.innerHTML = "";

  if (!query) return;

  const matches = schools.filter(school =>
    school.name.toLowerCase().includes(query)
  );

  matches.forEach(school => {
    const li = document.createElement("li");
    const a = document.createElement("a");

    a.href = school.url;
    a.target = "_blank";
    a.textContent = school.name;

    li.appendChild(a);
    results.appendChild(li);
  });
});
